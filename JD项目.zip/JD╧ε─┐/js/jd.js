/**
 * Created by С�� on 2016/10/13.
 */

window.onload = function(){
    var my_shopcar = document.getElementById("my_shopcar");
    my_shopcar.onmouseover = function () {
        var my_shopcar_alert = document.getElementById("my_shopcar_alert");
        my_shopcar_alert.style.display = "block";
    };
    my_shopcar.onmouseout = function () {
        var my_shopcar_alert = document.getElementById("my_shopcar_alert");
        my_shopcar_alert.style.display = "none";
    };


   /* var nav = document.getElementById("nav_list");
    var links = nav.getElementsByClassName("nav_li");
    var pop = document.getElementsByClassName("pop");
    for (var i = 0; i < links.length; i++) {
        links[i].onmouseover = function () {

        };
        var _ = 0;
    }*/

};


